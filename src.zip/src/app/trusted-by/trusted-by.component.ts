import { Component } from '@angular/core';

@Component({
  selector: 'app-trusted-by',
  standalone: true,
  imports: [],
  templateUrl: './trusted-by.component.html',
  styleUrl: './trusted-by.component.css',
})
export class TrustedByComponent {}
